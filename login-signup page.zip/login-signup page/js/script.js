const registerForm = document.getElementById("register");
const loginForm = document.getElementById("login");

const formsubmit = (formType) => {
    event.preventDefault();

    const form = formType === 'register' ? registerForm : loginForm;
    const fname = form.querySelector('[name="fname"]');
    const email = form.querySelector('[name="email"]');
    const pswd = form.querySelector('[name="pswd"]');
    const cpswd = form.querySelector('[name="cpswd"]');

    let firstname = fname.value.trim() !== '';
    let useremail = email.value.trim() !== '';
    let password = pswd.value.trim() !== '';
    let conformpass = cpswd.value.trim() !== '';

    if (!firstname) {
        fname.classList.add("empty");
    } else {
        fname.classList.remove("empty");
    }

    if (!useremail) {
        email.classList.add("empty");
    } else {
        email.classList.remove("empty");
    }

    if (!password) {
        pswd.classList.add("empty");
    } else {
        pswd.classList.remove("empty");
    }

    if (formType === 'register' && !conformpass) {
        cpswd.classList.add("empty");
    } else if (formType === 'register') {
        cpswd.classList.remove("empty");
    }

    if (firstname && useremail && password && (formType !== 'register' || conformpass)) {
        // Simulate form submission (replace with actual form submission logic)
        console.log(`${formType} Form submitted!`);

        // You can reset the form here if needed
        form.reset();

        // If you want to stay on the page, you can prevent the default behavior
        return false;
    } else {
        console.log(`${formType} Form not submitted due to validation errors.`);
        return false;
    }
};

registerForm.addEventListener("submit", (event) => formsubmit('register'));
loginForm.addEventListener("submit", (event) => formsubmit('login'));

// Function to validate an input and add the 'empty' class if it's empty
function validateInput(input) {
    if (input.value.trim() === '') {
        input.classList.add('empty');
    } else {
        input.classList.remove('empty');
    }
}
