 // fortext
 document.getElementById("curtainInput").addEventListener(
    "click",
    function(event) {
        if (event.target.innerText === "SUBSCRIBE") {
            event.target.innerText = "UNSUBSCRIBE";
        } else {
            event.target.innerText = "SUBSCRIBE";
        }
      },
    false
  );

  // forcss
  document.getElementById("curtainInput").addEventListener(
    "click",
    function(event) {
        if (event.target.classList.contains("clicked")) {
            event.target.classList.remove("clicked");
        } else {
            event.target.classList.add("clicked");
        }
    },
    false
  );
